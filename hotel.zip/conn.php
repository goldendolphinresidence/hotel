<?php
$conn = mysqli_connect("localhost", "u650820093_hotel", "Hotel15058181", "u650820093_hotel"); 
?>