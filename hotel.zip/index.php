
<br><br>
<a href="post_produto.php">1° Cadastra o Produto</a>
<br><br>
<a href="post_compra.php">2° Faz a Compra - Produto</a>
<br><br>
<a href="post_venda.php">3° Faz a Vendas - Produto</a>
<br><br>
